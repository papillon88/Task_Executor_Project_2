package edu.utdallas.taskExecutorImpl;

import edu.utdallas.taskExecutor.Task;
import edu.utdallas.taskExecutor.TaskExecutor;

public class TaskExecutorImpl implements TaskExecutor
{
	TaskRunner taskRunner;
	
	public TaskExecutorImpl(int poolSize)
	{
		taskRunner = new TaskRunner(poolSize);
		
		for (int i = 0; i < poolSize; i++)
		{
			taskRunner.threads[i] = new Thread(taskRunner);
			taskRunner.threads[i].setName("WorkingThread_" + i);
			taskRunner.threads[i].start();
		}
	}

	@Override
	public void addTask(Task task)
	{
		taskRunner.addTask(task);
	}  
}