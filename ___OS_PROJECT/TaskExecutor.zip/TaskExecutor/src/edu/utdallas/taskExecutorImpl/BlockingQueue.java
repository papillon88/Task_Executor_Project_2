package edu.utdallas.taskExecutorImpl;

import java.util.ArrayList;
import java.util.List;

import edu.utdallas.taskExecutor.Task;

/**
 * @(#)BlockingQueue.java
 *
 *
 * @author Scott Fontenarosa
 * @version 1.00 2014/10/28
 */

public class BlockingQueue
{
	List<Task> taskList;

    public BlockingQueue()
    {
    	taskList = new ArrayList<Task>();
    }

    public void add(Task task)
	{
    	taskList.add(task);
	}

    public Task retrieve()
    {
    	Task task = taskList.get(0);
    	this.dequeue();
    	return task;
    }
    
	public void dequeue()
	{
		if (this.isEmpty()) 
		{
			printQueueEmptyErrorMessage(); // display queue is empty message
			return;
		}
		else
		{			
			// make second task the first task
			taskList.remove(0);
		}		
	}

	// determines if queue is empty or not
	public boolean isEmpty()
	{
		return taskList.isEmpty();
	}

	private void printQueueEmptyErrorMessage()
	{
		System.out.println("<error> dequeue failed -- queue is currently empty");
	}
}