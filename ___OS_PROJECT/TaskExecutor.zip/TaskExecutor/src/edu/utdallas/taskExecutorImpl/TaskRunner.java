package edu.utdallas.taskExecutorImpl;

import edu.utdallas.taskExecutor.Task;

public class TaskRunner implements Runnable {

	Thread[] threads;
	BlockingQueue taskQueue = new BlockingQueue();
	
	TaskRunner(int poolSize)
	{
		threads = new Thread[poolSize];
	}
	
	@Override
	public void run()
	{
		this.runLoop();
	}
	
	// retrieves and executes tasks
	public void runLoop()
	{
		synchronized (this)
		{			
			if (taskQueue.isEmpty())
			{
				try
				{
					//System.out.println("BLOCKED Thread: " + Thread.currentThread().getName());
					this.wait();
					//System.out.println("RESUMED Thread: " + Thread.currentThread().getName());
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					taskQueue.retrieve().execute();
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			
			this.runLoop();
		}
	}
	
	public void addTask(Task task)
	{
		synchronized (this)
		{
			taskQueue.add(task);
			this.notify();
		}
	}
}
